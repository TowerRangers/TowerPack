local ADDON_NAME = ...
local TP = LibStub("AceAddon-3.0"):NewAddon(
    ADDON_NAME,
    "AceEvent-3.0",
    "AceConsole-3.0"
)

local ADDON_VERSION = C_AddOns.GetAddOnMetadata(ADDON_NAME, "Version") or "?"
_G[ADDON_NAME] = TP


local defaults = {
    profile = {

        minimap = {
            hide = false,
        },

        CVarManager = {
            friendlyNameOnly = false,
        },

        TalentUIScale = {
            enabled = true,
            scale = 0.85,
        },

        LFGAlert = {
            enabled = true,
            soundEnabled = true,
            height = 350,
            fontSize = 50,
            showTime = 3,
            fadeTime = 0.7,
            message = "새로운 신청자가 있습니다!",
        },

        SupplyAlert = {
            enabled = true,
            soundEnabled = true,
            iconX = 0,
            iconY = 150,
            whisper = true,
            duration = 30,
        },
	
        RuneAlert = {
            enabled = true,
            yOffset = 250,
            iconSize = 64,
            fontSize = 26,
	    hideWhileMounted = true,
        }
	
    }
}


local LDB
local LDBIcon

local LibDataBroker = LibStub("LibDataBroker-1.1", true)
if LibDataBroker then
    LDB = LibDataBroker:NewDataObject("TowerPack", {
        type = "launcher",
        icon = "Interface\\AddOns\\TowerPack\\icon.tga",

        OnClick = function(_, button)
            if button == "LeftButton" then
                TP:OpenConfig()
            end
        end,

        OnTooltipShow = function(tt)
            tt:AddLine("Tower Pack")
            tt:AddLine("|cffffcc00/tp|r 로 설정창 열기", 1, 1, 1)
        end,
    })
end


function TP:OpenConfig()

    local ACD = LibStub("AceConfigDialog-3.0", true)
    if not ACD then return end

    ACD:Open("TowerPack")

    local widget = ACD.OpenFrames and ACD.OpenFrames["TowerPack"]
    if widget and widget.frame then
        widget.frame:SetResizable(false)

        if widget.sizer_se then widget.sizer_se:Hide() end
        if widget.sizer_s then widget.sizer_s:Hide() end
        if widget.sizer_e then widget.sizer_e:Hide() end
    end
end


function TP:OnInitialize()

    self.db = LibStub("AceDB-3.0"):New("TowerPackDB", defaults, true)

    self:SetupOptions()

    LDBIcon = LibStub("LibDBIcon-1.0", true)

    if LDB and LDBIcon then
        LDBIcon:Register(
            "TowerPack",
            LDB,
            self.db.profile.minimap
        )
    end

    self:RegisterChatCommand("tp", function()
        TP:OpenConfig()
    end)
    
end


function TP:SetupOptions()

    local options = {
        type = "group",
        name = "Tower Pack (v" .. ADDON_VERSION .. ")",
        args = {

            MainSettings = {
                type = "group",
                name = "# 메인 설정",
                order = 0,
                args = {

                    minimapToggle = {
                        type = "toggle",
                        name = "미니맵 버튼 표시",
                        width = 1,
                        order = 1,
                        get = function()
                            return not self.db.profile.minimap.hide
                        end,
                        set = function(_, val)
                            self.db.profile.minimap.hide = not val

                            if val then
                                LibStub("LibDBIcon-1.0"):Show("TowerPack")
                            else
                                LibStub("LibDBIcon-1.0"):Hide("TowerPack")
                            end
                        end,
                    },

                    desc = {
                        type = "description",
                        name = "\n|cffaaaaaa/tp|r 명령어로도 설정창을 열 수 있습니다.",
                        fontSize = "medium",
                        width = "full",
                        order = 2,
                    },

                },
            },
	    
            CVarManager = {
                type = "group",
                name = "CVar 설정관리",
                order = 1,
                args = {
		
                    friendlyHeader = {
                        type = "header",
                        name = "아군 플레이어 이름만 표시 (체력바 숨김)",
                        order = 1,
                    },		
		
                    friendlyNameOnly = {
                        type = "toggle",
                        name = "활성화",
                        width = 0.5,
			order = 2,
			get = function()
			    return TP.db.profile.CVarManager.friendlyNameOnly
			end,
                        set = function(_, value)
			    TP.CVarManager:OnToggleChanged(value)
                        end,
                    },
		    
                    desc = {
                        type = "description",
                        name = "\n|cffaaaaaaPlater|r 나 |cffaaaaaaPlatynator|r 사용시 아군 플레이어 이름만 표시 설정을\n덮어 씌워버리는 경우 값을 재정의 합니다.\n\n활성화 시 |cffaaaaaaAdvancedInterfaceOptions|r 나 |cffaaaaaaCVar|r 명령어로\n강제로 값을 업데이트 해도 유지됩니다.\n\n(추종자 던전에서는 동작하지 않습니다)",
                        fontSize = "medium",
                        width = "full",
                        order = 99,
                    },
		    
                },
            },	    

            TalentUIScale = {
                type = "group",
                name = "특성 & 마법책 스케일",
                order = 2,
                args = {

                    enabled = {
                        type = "toggle",
                        name = "활성화",
			width = 0.5,
			order = 1,
                        get = function()
                            return self.db.profile.TalentUIScale.enabled
                        end,
                        set = function(_, v)
                            self.db.profile.TalentUIScale.enabled = v
                            if TP.Talent then
                                TP.Talent:ApplyScale()
                            end
                        end,
                    },
		    
                    spacer = {
                        order = 2,
                        type = "description",
                        name = " ",
                        width = 1.5,
                    },		    
		    
                    resetDefault = {
                        order = 3,
                        type = "execute",
                        name = "기본설정",
                        width = 0.5,
                        func = function()
                            TP.db.profile.TalentUIScale = CopyTable(defaults.profile.TalentUIScale)
                            if TP.Talent then
                                TP.Talent:ApplyScale()
                            end

                            LibStub("AceConfigRegistry-3.0"):NotifyChange("TowerPack")
                        end,
                    },		    

                    scale = {
                        type = "range",
                        name = "스케일",
                        min = 0.5,
                        max = 1,
                        step = 0.05,
			width = 1.2,
			order = 4,
                        get = function()
                            return self.db.profile.TalentUIScale.scale
                        end,
                        set = function(_, v)
                            self.db.profile.TalentUIScale.scale = v
                            if TP.Talent then
                                TP.Talent:ApplyScale()
                            end
                        end,
                    },
		    
                    desc = {
                        type = "description",
                        name = "\n특성창 및 마법책의 크기를 조절합니다.\n\n(전투 중에는 즉시 적용되지 않을 수 있습니다)",
                        fontSize = "medium",
                        width = "full",
                        order = 99,
                    },
		    
                }
            },

            LFGAlert = {
                type = "group",
                name = "파티 신청 알림",
                order = 3,
                args = {

                    enabled = {
                        type = "toggle",
                        name = "활성화",
                        width = 0.5,
                        order = 1,
                        get = function()
                            return self.db.profile.LFGAlert.enabled
                        end,
                        set = function(_, v)
                            self.db.profile.LFGAlert.enabled = v
                        end,
                    },
		    
                    spacer = {
                        order = 2,
                        type = "description",
                        name = " ",
                        width = 1.5,
                    },		    
		    
                    resetDefault = {
                        order = 3,
                        type = "execute",
                        name = "기본설정",
                        width = 0.5,
                        func = function()
                            TP.db.profile.LFGAlert = CopyTable(defaults.profile.LFGAlert)
                            if TP.LFG then
                                TP.LFG:ApplySettings()
                            end

                            LibStub("AceConfigRegistry-3.0"):NotifyChange("TowerPack")
                        end,
                    },

                    message = {
                        type = "input",
                        name = "알림 메시지",
                        width = 2,
                        order = 4,
                        get = function()
                            return self.db.profile.LFGAlert.message
                        end,
                        set = function(_, v)
                            self.db.profile.LFGAlert.message = v
                        end,
                    },

                    height = {
                        type = "range",
                        name = "위치 (Y축)",
                        min = -500,
                        max = 500,
                        step = 5,
                        width = 1.2,
                        order = 5,
                        get = function()
                            return self.db.profile.LFGAlert.height
                        end,
                        set = function(_, v)
                            self.db.profile.LFGAlert.height = v
                            if TP.LFG then
                                TP.LFG:ApplySettings()
                            end
                        end,
                    },

                    fontSize = {
                        type = "range",
                        name = "폰트 크기",
                        min = 20,
                        max = 100,
                        step = 1,
                        width = 1.2,
                        order = 6,
                        get = function()
                            return self.db.profile.LFGAlert.fontSize
                        end,
                        set = function(_, v)
                            self.db.profile.LFGAlert.fontSize = v
                            C_Timer.After(0.05, function()
                                if TP.LFG then
                                    TP.LFG:ApplySettings()
                                end
                            end)
                        end,
                    },

                    showTime = {
                        type = "range",
                        name = "표시 시간",
                        min = 1,
                        max = 10,
                        step = 0.1,
                        width = 1.2,
                        order = 7,
                        get = function()
                            return self.db.profile.LFGAlert.showTime
                        end,
                        set = function(_, v)
                            self.db.profile.LFGAlert.showTime = v
                        end,
                    },

                    fadeTime = {
                        type = "range",
                        name = "페이드 시간",
                        min = 0.1,
                        max = 3,
                        step = 0.1,
                        width = 1.2,
                        order = 8,
                        get = function()
                            return self.db.profile.LFGAlert.fadeTime
                        end,
                        set = function(_, v)
                            self.db.profile.LFGAlert.fadeTime = v
                        end,
                    },
		    
                    soundEnabled = {
                        type = "toggle",
                        name = "사운드 활성화",
                        width = 1.2,
                        order = 9,
                        get = function()
                            return self.db.profile.LFGAlert.soundEnabled
                        end,
                        set = function(_, v)
                            self.db.profile.LFGAlert.soundEnabled = v
                        end,
                    },

                    testStart = {
                        type = "execute",
                        name = "테스트",
                        width = 1.2,
                        order = 10,
                        func = function()
                            if TP.LFG then
                                TP.LFG:TestFromMain()
                            end
                        end,
                    },
		    
                    desc = {
                        type = "description",
                        name = "\n파티 구인중 신청자가 있는 경우 알림을 표시하고 자동으로 파티 구성하기 창을 엽니다.\n(전투중 일때는 알림만 표시됩니다)\n\n※ 파티 구성창이 열려있는 상태에서는 작동하지 않습니다.",
                        fontSize = "medium",
                        width = "full",
                        order = 99,
                    },
		    
                }
            },

            SupplyAlert = {
                type = "group",
                name = "전쟁 보급품 알림",
                order = 4,
                args = {

                    enabled = {
                        type = "toggle",
                        name = "활성화",
                        width = 0.5,
                        order = 1,
                        get = function()
                            return self.db.profile.SupplyAlert.enabled
                        end,
                        set = function(_, v)
                            self.db.profile.SupplyAlert.enabled = v
                        end,
                    },
		    
                    spacer = {
                        order = 2,
                        type = "description",
                        name = " ",
                        width = 1.5,
                    },		    
		    
                    resetDefault = {
                        order = 3,
                        type = "execute",
                        name = "기본설정",
                        width = 0.5,
                        func = function()
                            TP.db.profile.SupplyAlert = CopyTable(defaults.profile.SupplyAlert)
                            if TP.Supply then
                                TP.Supply:ApplySettings()
                            end			    
			    
			    LibStub("AceConfigRegistry-3.0"):NotifyChange("TowerPack")
                        end,
                    },		    

                    iconX = {
                        type = "range",
                        name = "위치 (X축)",
                        min = -500,
                        max = 500,
                        step = 5,
                        width = 1.2,
                        order = 4,
                        get = function()
                            return self.db.profile.SupplyAlert.iconX
                        end,
                        set = function(_, v)
                            self.db.profile.SupplyAlert.iconX = v
                            if TP.Supply then
                                TP.Supply:ApplySettings()
                            end
                        end,
                    },

                    iconY = {
                        type = "range",
                        name = "위치 (Y축)",
                        min = -500,
                        max = 500,
                        step = 5,
                        width = 1.2,
                        order = 5,
                        get = function()
                            return self.db.profile.SupplyAlert.iconY
                        end,
                        set = function(_, v)
                            self.db.profile.SupplyAlert.iconY = v
                            if TP.Supply then
                                TP.Supply:ApplySettings()
                            end
                        end,
                    },

                    duration = {
                        type = "range",
                        name = "표시 시간",
                        min = 5,
                        max = 120,
                        step = 1,
                        width = 1.2,
                        order = 6,
                        get = function()
                            return self.db.profile.SupplyAlert.duration
                        end,
                        set = function(_, v)
                            self.db.profile.SupplyAlert.duration = v
                        end,
                    },

                    whisper = {
                        type = "toggle",
                        name = "귓속말 알림 (비 전투시만)",
                        width = 1.2,
                        order = 7,
                        get = function()
                            return self.db.profile.SupplyAlert.whisper
                        end,
                        set = function(_, v)
                            self.db.profile.SupplyAlert.whisper = v
                        end,
                    },
		    
                    soundEnabled = {
                        type = "toggle",
                        name = "사운드 활성화",
                        width = "full",
                        order = 8,
                        get = function()
                            return self.db.profile.SupplyAlert.soundEnabled
                        end,
                        set = function(_, v)
                            self.db.profile.SupplyAlert.soundEnabled = v
                        end,
                    },		    
		    
                    spacer1 = {
                        type = "description",
                        name = " ",
                        width = "full",
                        order = 9,
                    },    

                    testStart = {
                        type = "execute",
                        name = "테스트 시작",
                        width = 1.2,
                        order = 10,
                        func = function()
                            if TP.Supply then
                                TP.Supply:TestStart()
                            end
                        end,
                    },

                    testStop = {
                        type = "execute",
                        name = "테스트 중지",
                        width = 1.2,
                        order = 11,
                        func = function()
                            if TP.Supply then
                                TP.Supply:TestStop()
                            end
                        end,
                    },
		    
                    desc = {
                        type = "description",
                        name = "\n전쟁 모드에서 보급 상자가 도착하면 알림 아이콘과 함께 사운드를 재생합니다.\n\n귓속말 알림을 활성화하면,\n비 전투시 백그라운드 상태에서도 작업 표시줄이 점멸합니다.\n\n(마우스 우클릭 시 닫힙니다)",
                        fontSize = "medium",
                        width = "full",
                        order = 99,
                    },
		    
                }
            },

            RuneAlert = {
                order = 5,
                type = "group",
                name = "증강의 룬 알림",
                args = {

                    enabled = {
                        order = 1,
                        type = "toggle",
                        name = "활성화",
                        width = 0.5,
                        get = function()
                            return TP.db.profile.RuneAlert.enabled
                        end,
                        set = function(_, val)
                            TP.db.profile.RuneAlert.enabled = val
                            TP.RuneAlert:EvaluateState()
                        end,
                    },
		    
                    spacer = {
                        order = 2,
                        type = "description",
                        name = " ",
                        width = 1.5,
                    },
		    
                    resetDefault = {
                        order = 3,
                        type = "execute",
                        name = "기본설정",
                        width = 0.5,
                        func = function()

                            TP.db.profile.RuneAlert = CopyTable(defaults.profile.RuneAlert)

                            TP.RuneAlert:ApplySettings()
                            TP.RuneAlert:EvaluateState()

                        end,
                    },

                    yOffset = {
                        order = 4,
                        type = "range",
                        name = "위치 (Y축)",
                        width = 1.2,
                        min = -500, max = 500, step = 5,
                        get = function()
                            return TP.db.profile.RuneAlert.yOffset
                        end,
                        set = function(_, val)
                            TP.db.profile.RuneAlert.yOffset = val
			    TP.RuneAlert:ApplySettings()
                        end,
                    },

                    hideWhileMounted = {
                        order = 5,
                        type = "toggle",
                        name = "탈것 탑승 시 숨김",
                        width = 1.2,
                        get = function()
                            return TP.db.profile.RuneAlert.hideWhileMounted
                        end,
                        set = function(_, val)
                            TP.db.profile.RuneAlert.hideWhileMounted = val
                            TP.RuneAlert:EvaluateState()
                        end,
                    },

                    iconSize = {
                        order = 6,
                        type = "range",
                        name = "아이콘 크기",
                        width = 1.2,
                        min = 32, max = 128, step = 1,
                        get = function()
                            return TP.db.profile.RuneAlert.iconSize
                        end,
                        set = function(_, val)
                            TP.db.profile.RuneAlert.iconSize = val
			    TP.RuneAlert:ApplySettings()
                        end,
                    },

                    fontSize = {
                        order = 7,
                        type = "range",
                        name = "폰트 크기",
                        width = 1.2,
                        min = 12, max = 40, step = 1,
                        get = function()
                            return TP.db.profile.RuneAlert.fontSize
                        end,
                        set = function(_, val)
                            TP.db.profile.RuneAlert.fontSize = val
			    TP.RuneAlert:ApplySettings()
                        end,
                    },

                    spacer1 = {
                        type = "description",
                        name = " ",
                        width = "full",
                        order = 8,
                    },

                    priorityGroup = {
                        order = 9,
                        type = "group",
                        name = "우선순위",
                        inline = true,
                        args = {

                            line1 = {
                                type = "description",
                                name = "1순위 - 실체없는 증강의 룬 (내부전쟁)",
                                width = "full",
                            },

                            line2 = {
                                type = "description",
                                name = "2순위 - 꿈결속 증강의 룬 (용군단)",
                                width = "full",
                            },
                        },
                    },

                    desc = {
                        order = 99,
                        type = "description",
                        name = "\n가방에 해당 아이템이 존재할 때만 표시됩니다.\n\n활성화 상태라고 하더라도, 룬을 보유중이지 않은 저레벨의 경우 작동하지 않습니다.",
                        width = "full",
                        fontSize = "medium",
                    },
                },
            },

        }
    }

    LibStub("AceConfig-3.0"):RegisterOptionsTable("TowerPack", options)

    local ACD = LibStub("AceConfigDialog-3.0", true)
    if ACD then
        ACD:AddToBlizOptions("TowerPack", "TowerPack")
    end
end


function TP:OnEnable()

    if self.CVarManager and self.CVarManager.ApplySettings then
        self.CVarManager:ApplySettings()
    end

    if self.Talent and self.Talent.ApplyScale then
        self.Talent:ApplyScale()
    end

    if self.LFG and self.LFG.ApplySettings then
        self.LFG:ApplySettings()
    end

    if self.Supply and self.Supply.ApplySettings then
        self.Supply:ApplySettings()
    end
    
    if self.RuneAlert and self.RuneAlert.ApplySettings then
        self.RuneAlert:ApplySettings()
    end    
end