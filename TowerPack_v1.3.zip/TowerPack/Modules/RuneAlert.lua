local TP = LibStub("AceAddon-3.0"):GetAddon("TowerPack")

TP.RuneAlert = {}
local RuneAlert = TP.RuneAlert

local RUNES = {
    { itemID = 243191, buffID = 1234969 },
    { itemID = 211495, buffID = 393438 },
}

local runeButton
local visual
local blink
local eventFrame
local cooldownTicker
local activeRune
local initialized = false

local function FindActiveRune()
    for _, rune in ipairs(RUNES) do
        for bag = 0, NUM_BAG_SLOTS do
            for slot = 1, C_Container.GetContainerNumSlots(bag) do
                if C_Container.GetContainerItemID(bag, slot) == rune.itemID then
                    return rune
                end
            end
        end
    end
end

local function HasActiveRuneBuff()
    if not activeRune then return false end
    return C_UnitAuras.GetPlayerAuraBySpellID(activeRune.buffID) ~= nil
end

local function GetCooldownRemaining()
    if not activeRune then return 0 end
    local start, duration = C_Item.GetItemCooldown(activeRune.itemID)
    if not start or duration == 0 then return 0 end
    return start + duration - GetTime()
end

local function IsItemUsable()
    if not activeRune then return false end
    return C_Item.IsUsableItem(activeRune.itemID)
end

local function StopCooldownWatcher()
    if cooldownTicker then
        cooldownTicker:Cancel()
        cooldownTicker = nil
    end
end

local function StartCooldownWatcher(self)
    if cooldownTicker then return end
    cooldownTicker = C_Timer.NewTicker(0.5, function()
        if GetCooldownRemaining() <= 0 then
            StopCooldownWatcher()
            self:EvaluateState()
        end
    end)
end

local function UpdateSecureButton()
    if not runeButton or not activeRune then return end
    if InCombatLockdown() then return end

    runeButton:SetAttribute("macrotext", "/use item:" .. activeRune.itemID)
    visual.icon:SetTexture(C_Item.GetItemIconByID(activeRune.itemID))
    visual.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
end

function RuneAlert:EvaluateState()

    if not TP.db.profile.RuneAlert.enabled then
        if visual then visual:Hide() end
        StopCooldownWatcher()
        return
    end

    activeRune = FindActiveRune()

    if not activeRune then
        if visual then visual:Hide() end
        StopCooldownWatcher()
        return
    end

    UpdateSecureButton()

    if HasActiveRuneBuff() then
        if visual then visual:Hide() end
        StopCooldownWatcher()
        return
    end

    if not IsItemUsable() then
        if visual then visual:Hide() end
        StopCooldownWatcher()
        return
    end

    if InCombatLockdown() then
        if visual then visual:Hide() end
        return
    end

    if TP.db.profile.RuneAlert.hideWhileMounted and IsMounted() then
        if visual then visual:Hide() end
        return
    end

    local remaining = GetCooldownRemaining()

    if remaining > 0 then
        if visual then visual:Hide() end
        StartCooldownWatcher(self)
    else
        StopCooldownWatcher()
        if visual then
            visual:SetAlpha(1)
            visual:Show()
            blink:Play()
        end
    end
end

local function OnEvent(self, event, arg1)
    if event == "BAG_UPDATE_DELAYED" then
        self:EvaluateState()
    elseif event == "UNIT_AURA" and arg1 == "player" then
        self:EvaluateState()
    elseif event == "PLAYER_REGEN_DISABLED" then
        if visual then visual:Hide() end
    elseif event == "PLAYER_REGEN_ENABLED" then
        self:EvaluateState()
    elseif event == "PLAYER_MOUNT_DISPLAY_CHANGED" then
        self:EvaluateState()
    end
end

function RuneAlert:Initialize()

    if initialized then return end
    initialized = true

    local db = TP.db.profile.RuneAlert

    runeButton = CreateFrame("Button", "TP_RuneButton", UIParent, "SecureActionButtonTemplate")
    runeButton:SetSize(db.iconSize, db.iconSize)
    runeButton:SetPoint("CENTER", UIParent, "CENTER", 0, db.yOffset)
    runeButton:SetFrameStrata("FULLSCREEN_DIALOG")
    runeButton:SetAttribute("type", "macro")
    runeButton:RegisterForClicks("AnyUp", "AnyDown")

    visual = CreateFrame("Frame", nil, runeButton)
    visual:SetAllPoints()
    visual:Hide()

    visual.icon = visual:CreateTexture(nil, "BACKGROUND")
    visual.icon:SetAllPoints()

    visual.text = visual:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    visual.text:SetFont(STANDARD_TEXT_FONT, db.fontSize, "OUTLINE")
    visual.text:SetPoint("TOP", visual, "BOTTOM", 0, -8)
    visual.text:SetText("증강 룬")
    visual.text:SetTextColor(1, 1, 1)

    blink = visual:CreateAnimationGroup()
    blink:SetLooping("REPEAT")

    local fadeOut = blink:CreateAnimation("Alpha")
    fadeOut:SetFromAlpha(1)
    fadeOut:SetToAlpha(0)
    fadeOut:SetDuration(0.3)
    fadeOut:SetOrder(1)

    local fadeIn = blink:CreateAnimation("Alpha")
    fadeIn:SetFromAlpha(0)
    fadeIn:SetToAlpha(1)
    fadeIn:SetDuration(0.3)
    fadeIn:SetOrder(2)

    runeButton:HookScript("PostClick", function()
        C_Timer.After(0.1, function()
            RuneAlert:EvaluateState()
        end)
    end)

    eventFrame = CreateFrame("Frame")
    eventFrame:RegisterEvent("BAG_UPDATE_DELAYED")
    eventFrame:RegisterEvent("UNIT_AURA")
    eventFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
    eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    eventFrame:RegisterEvent("PLAYER_MOUNT_DISPLAY_CHANGED")
    eventFrame:SetScript("OnEvent", function(_, event, arg1)
        OnEvent(RuneAlert, event, arg1)
    end)
end

function RuneAlert:ApplySettings()
    self:Initialize()

    local db = TP.db.profile.RuneAlert

    if runeButton then
        runeButton:ClearAllPoints()
        runeButton:SetPoint("CENTER", UIParent, "CENTER", 0, db.yOffset)
        runeButton:SetSize(db.iconSize, db.iconSize)
    end

    if visual then
        visual:SetSize(db.iconSize, db.iconSize)
    end

    if visual and visual.text then
        visual.text:SetFont(STANDARD_TEXT_FONT, db.fontSize, "OUTLINE")
    end

    self:EvaluateState()
end
