local TP = LibStub("AceAddon-3.0"):GetAddon("TowerPack")

TP.LFG = {}
local LFG = TP.LFG

LFG.testMode = nil


local FloatingAlert = CreateFrame("Frame", "LFGApplicantFloatingAlert", UIParent)
FloatingAlert:SetSize(1000, 200)
FloatingAlert:SetFrameStrata("TOOLTIP")
FloatingAlert:SetFrameLevel(9999)
FloatingAlert:Hide()

local FloatingText = FloatingAlert:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
FloatingText:SetAllPoints()
FloatingText:SetJustifyH("CENTER")
FloatingText:SetJustifyV("MIDDLE")

TP.LFG.frame = FloatingAlert
TP.LFG.text  = FloatingText

local lastHeight
local lastFontSize


function LFG:ShowAlert()

    local db = TP.db.profile.LFGAlert
    if not db.enabled then return end

    if PVEFrame and PVEFrame:IsVisible() then
        return
    end

    self:ApplySettings()

    FloatingText:SetText(db.message)
    FloatingAlert:SetAlpha(1)
    FloatingAlert:Show()

    if db.soundEnabled then
        PlaySound(SOUNDKIT.ALARM_CLOCK_WARNING_3)
    end

    if not InCombatLockdown() then
        if self.testMode ~= "config" then

            if not C_AddOns.IsAddOnLoaded("Blizzard_GroupFinder") then
                C_AddOns.LoadAddOn("Blizzard_GroupFinder")
            end

            PVEFrame_ShowFrame("GroupFinderFrame")

            C_Timer.After(0.1, function()
                if GroupFinderFrameGroupButton3 then
                    local func = GroupFinderFrameGroupButton3:GetScript("OnClick")
                    if func then
                        func(GroupFinderFrameGroupButton3)
                    end
                end
            end)
        end
    end

    C_Timer.After(db.showTime, function()
        UIFrameFadeOut(FloatingAlert, db.fadeTime, 1, 0)

        C_Timer.After(db.fadeTime + 0.05, function()
            FloatingAlert:Hide()
        end)
    end)
end


function LFG:TestFromConfig()
    self.testMode = "config"
    self:ShowAlert()
    self.testMode = nil
end

function LFG:TestFromMain()
    self.testMode = "main"
    self:ShowAlert()
    self.testMode = nil
end


local eventFrame = CreateFrame("Frame")
local lastApplicantCount = 0
local initialized = false
local lastAlertTime = 0

eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("LFG_LIST_APPLICANT_UPDATED")
eventFrame:RegisterEvent("LFG_LIST_APPLICANT_LIST_UPDATED")
eventFrame:RegisterEvent("LFG_LIST_ACTIVE_ENTRY_UPDATE")

local function IsLeader()
    return UnitIsGroupLeader("player")
end

local function CanTrigger()
    return (IsInGroup() or IsInRaid()) and IsLeader()
end

local function GetApplicantCount()
    local t = C_LFGList.GetApplicants()
    return t and #t or 0
end

local function IsGroupFinderVisible()
    return PVEFrame and PVEFrame:IsVisible()
end

local function FireAlert()

    if IsGroupFinderVisible() then return end

    local now = GetTime()
    if now - lastAlertTime < 3 then return end
    lastAlertTime = now

    LFG.testMode = nil
    LFG:ShowAlert()
end

eventFrame:SetScript("OnEvent", function(self, event)

    if event == "PLAYER_LOGIN" then
        C_AddOns.LoadAddOn("Blizzard_GroupFinder")
        lastApplicantCount = GetApplicantCount()
        initialized = true
        return
    end

    if not initialized then return end
    if not CanTrigger() then return end

    C_Timer.After(0.1, function()

        local current = GetApplicantCount()

        if current > lastApplicantCount then
            FireAlert()
        end

        lastApplicantCount = current
    end)
end)

function TP.LFG:ApplySettings()

    if not self.frame then return end

    local db = TP.db.profile.LFGAlert

    self.frame:ClearAllPoints()
    self.frame:SetPoint("CENTER", UIParent, "CENTER", 0, db.height)

    if self.text then
        self.text:SetFont(STANDARD_TEXT_FONT, db.fontSize, "OUTLINE")
    end

end
