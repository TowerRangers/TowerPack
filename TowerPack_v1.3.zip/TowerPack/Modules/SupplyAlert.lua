local TP = LibStub("AceAddon-3.0"):GetAddon("TowerPack")

TP.Supply = {}
local Supply = TP.Supply


local TRIGGERS = {
    ["러피오스"] = {
        "이 근처에 자원 보관함이 있어",
        "기회가 왔어",
        "근처에 보물이 있는 것 같아",
        "이 지역에 귀중한 자원이 있어",
    },
    ["말리시아"] = {
        "다들 자원이 부족해 보이는데",
    }
}

local frame = CreateFrame("Button", "TPSupplyAlert", UIParent)
TP.Supply.frame = frame
frame:SetSize(64, 64)
frame:Hide()

frame:SetFrameStrata("TOOLTIP")
frame:SetFrameLevel(9999)

frame:EnableMouse(true)
frame:RegisterForClicks("AnyUp")

frame.icon = frame:CreateTexture(nil, "ARTWORK")
frame.icon:SetAllPoints()
frame.icon:SetTexture(1542856)
frame.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)

frame.text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
frame.text:SetPoint("TOP", frame, "BOTTOM", 0, -4)
frame.text:SetText("보급")
frame.text:SetFont(STANDARD_TEXT_FONT, 29, "OUTLINE")
frame.text:SetTextColor(1, 0.5, 0.03)


local blink = frame:CreateAnimationGroup()
blink:SetLooping("REPEAT")

local fadeOut = blink:CreateAnimation("Alpha")
fadeOut:SetFromAlpha(1)
fadeOut:SetToAlpha(0)
fadeOut:SetDuration(0.4)
fadeOut:SetOrder(1)

local fadeIn = blink:CreateAnimation("Alpha")
fadeIn:SetFromAlpha(0)
fadeIn:SetToAlpha(1)
fadeIn:SetDuration(0.4)
fadeIn:SetOrder(2)


local hideTimer
local sirenTicker
local SIREN_PATH = "Interface\\AddOns\\TowerPack\\Media\\WarningSiren.ogg"
local SIREN_LENGTH = 3.7

local function HideAlert()
    blink:Stop()
    frame:Hide()

    if sirenTicker then
        sirenTicker:Cancel()
        sirenTicker = nil
    end

    if hideTimer then
        hideTimer:Cancel()
        hideTimer = nil
    end
end


frame:EnableMouse(true)
frame:RegisterForClicks("AnyUp")

frame:SetScript("OnMouseUp", function(self, button)
    if button == "RightButton" then
        if self:IsShown() then
            HideAlert()
        end
    end
end)


local function ShowAlert()
    local db = TP.db.profile.SupplyAlert
    if not db.enabled then return end

    if sirenTicker then
        sirenTicker:Cancel()
        sirenTicker = nil
    end

    if hideTimer then
        hideTimer:Cancel()
        hideTimer = nil
    end

    Supply:ApplySettings()

    frame:SetAlpha(1)
    frame:Show()
    blink:Play()

    if db.soundEnabled then

        PlaySoundFile(SIREN_PATH, "Master")

        sirenTicker = C_Timer.NewTicker(SIREN_LENGTH, function()
            PlaySoundFile(SIREN_PATH, "Master")
        end)
    
    end

    if db.whisper and not InCombatLockdown() then
        SendChatMessage("보급", "WHISPER", nil, UnitName("player"))
    end

    hideTimer = C_Timer.NewTimer(db.duration, HideAlert)
end


frame:RegisterEvent("CHAT_MSG_MONSTER_SAY")
frame:RegisterEvent("CHAT_MSG_MONSTER_YELL")

frame:SetScript("OnEvent", function(_, event, msg, npcName)
    if not msg or not npcName then return end

    local npc = npcName:gsub("%s+", "")
    local triggers = TRIGGERS[npc]
    if not triggers then return end

    for _, text in ipairs(triggers) do
        if msg:find(text) then
            ShowAlert()
            return
        end
    end
end)


function Supply:TestStart()
    ShowAlert()
end

function Supply:TestStop()
    HideAlert()
end


function TP.Supply:ApplySettings()
    if not self.frame then return end

    local db = TP.db.profile.SupplyAlert

    self.frame:ClearAllPoints()
    self.frame:SetPoint("CENTER", UIParent, "CENTER", db.iconX, db.iconY)
end
