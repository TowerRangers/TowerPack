local TP = LibStub("AceAddon-3.0"):GetAddon("TowerPack")

TP.CVarManager = {}
local CVarManager = TP.CVarManager

local TARGET_CVAR = "nameplateShowOnlyNameForFriendlyPlayerUnits"

local monitorFrame = CreateFrame("Frame")
monitorFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
monitorFrame:RegisterEvent("CVAR_UPDATE")

function CVarManager:Apply()
    if not TP.db or not TP.db.profile or not TP.db.profile.CVarManager then
        return
    end

    local desired = TP.db.profile.CVarManager.friendlyNameOnly and "1" or "0"
    if GetCVar(TARGET_CVAR) ~= desired then
        SetCVar(TARGET_CVAR, desired)
    end
end

function CVarManager:OnToggleChanged(value)
    if not TP.db or not TP.db.profile or not TP.db.profile.CVarManager then
        return
    end

    TP.db.profile.CVarManager.friendlyNameOnly = value
    self:Apply()
end

monitorFrame:SetScript("OnEvent", function(self, event, name)

    if event == "PLAYER_ENTERING_WORLD" then

        C_Timer.After(1, function()
            CVarManager:Apply()
        end)

    elseif event == "CVAR_UPDATE" and name == TARGET_CVAR then

        local current = GetCVar(TARGET_CVAR)

        if TP.db.profile.CVarManager.friendlyNameOnly then
            if current ~= "1" then
                C_Timer.After(0, function()
                    SetCVar(TARGET_CVAR, "1")
                end)
            end
        else
            local newValue = (current == "1")
            if TP.db.profile.CVarManager.friendlyNameOnly ~= newValue then
                TP.db.profile.CVarManager.friendlyNameOnly = newValue
                LibStub("AceConfigRegistry-3.0"):NotifyChange("TowerPack")
            end
        end

    end

end)

function CVarManager:ApplySettings()
    self:Apply()
end
