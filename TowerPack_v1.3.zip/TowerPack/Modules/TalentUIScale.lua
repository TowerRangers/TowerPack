local TP = LibStub("AceAddon-3.0"):GetAddon("TowerPack")

TP.Talent = {}
local Talent = TP.Talent

local pending = false

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_REGEN_ENABLED")


local function ApplyScale()

    if not PlayerSpellsFrame then return end
    if not TP or not TP.db then return end

    local db = TP.db.profile.TalentUIScale

    if InCombatLockdown() then
        pending = true
        return
    end

    if not db.enabled then
        PlayerSpellsFrame:SetScale(1)
    else
        PlayerSpellsFrame:SetScale(db.scale)
    end

    pending = false
end


f:SetScript("OnEvent", function(_, event, addonName)

    if event == "ADDON_LOADED" and addonName == "Blizzard_PlayerSpells" then

        if PlayerSpellsFrame then

            PlayerSpellsFrame:HookScript("OnShow", function()
                ApplyScale()
            end)

            if PlayerSpellsFrame:IsShown() then
                ApplyScale()
            end
        end

    elseif event == "PLAYER_REGEN_ENABLED" then
        if pending and PlayerSpellsFrame and PlayerSpellsFrame:IsShown() then
            ApplyScale()
        end
    end
end)



function TP.Talent:ApplyScale()
    ApplyScale()
end
